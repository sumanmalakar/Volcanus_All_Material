import React, { useContext, useEffect, useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  Modal,
  TextField,
  Typography,
} from '@mui/material';
import axios from 'axios';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import SideBar from '../components/SideBar';
import { myContext } from '../context/Appcontext';

const Services = () => {
  const [servicesId, setservicesId] = useState('');

  const [serviceInput, setserviceInput] = useState({ title: '', description: '' });
  const [openAddModal, setOpenAddModal] = useState(false);
  const [openEditModal, setOpenEditModal] = useState(false);
  const serviceContext = useContext(myContext);
  const {
    servicedetails, setservicedetails,
    addService,
    updateService,
    deleteService,
    token,
    url,
    userId,
    reload,
  } = serviceContext;
  const { title, description } = serviceInput;

  // Onchange handler for input fields
  const serviceHandleChange = (e) => {
    const { name, value } = e.target;
    setserviceInput({ ...serviceInput, [name]: value });
  };

  // Submit handler for adding service
  const addServiceSubmit = async (e) => {
    e.preventDefault();
    await addService(title, description);
    setserviceInput({ title: '', description: '' }); // Reset input fields
    handleCloseAddModal(); // Close modal after submission
  };

  // Submit handler for updating service
  const updateServiceSubmit = async (e) => {
    e.preventDefault();
    await updateService(servicesId, title, description);
    handleCloseEditModal(); // Close modal after submission
  };

  // Set service id and input fields when servicedetails change
  useEffect(() => {
    if (servicedetails.length > 0) {
      setservicesId(servicedetails[0]._id);
      setserviceInput({
        title: servicedetails[0].title,
        description: servicedetails[0].description,
      });
    } else {
      setserviceInput({ title: '', description: '' });
    }
  }, [servicedetails, token, reload]);

  // Fetch services by userId on initial load and reload
  useEffect(() => {
    const getServiceByuserId = async (userid) => {
      try {
        const api = await axios.get(
          `${url}/service/getservicesbyUserId/${userid}`,
          {
            headers: {
              'Content-Type': 'application/json',
              Auth: token,
            },
            withCredentials: true,
          }
        );
        if (api.data.services) {
          setservicedetails(api.data.services);
        } else {
          setservicedetails([]);
        }
      } catch (error) {
        console.log(error.message);
      }
    };
    getServiceByuserId(userId);
  }, [token, userId, reload]);

  // Delete service by id
  const handleDelete = async (id) => {
    await deleteService(id);
    setserviceInput({ title: '', description: '' });
  };

  // Open modal for adding service
  const handleOpenAddModal = () => {
    setOpenAddModal(true);
    setserviceInput({ title: '', description: '' }); // Reset input fields
  };

  // Close modal for adding service
  const handleCloseAddModal = () => {
    setOpenAddModal(false);
  };

  // Open modal for editing service
  const handleOpenEditModal = (service) => {
    setservicesId(service._id);
    setserviceInput({
      title: service.title,
      description: service.description,
    });
    setOpenEditModal(true);
  };

  // Close modal for editing service
  const handleCloseEditModal = () => {
    setOpenEditModal(false);
    setserviceInput({ title: '', description: '' }); // Clear input fields
    setservicesId('');
  };

  return (
    <>
      <Box
        sx={{
          display: 'flex',
          backgroundColor: 'rgb(238,238,238)',
          height: '100vh',
        }}
      >
        <SideBar />
        <Box
          component="main"
          sx={{ flexGrow: 1, p: 3, marginTop: '3rem', position: 'relative' }}
        >
          {servicedetails.length === 0 && (
            <Card sx={{ maxWidth: 600, margin: 'auto', mt: 4 }}>
              <CardContent>
                <Typography variant="h5" align="center" color="textSecondary">
                  No services available
                </Typography>
                <Typography
                  variant="body1"
                  align="center"
                  color="textSecondary"
                >
                  Click below to add a new service.
                </Typography>
              </CardContent>
              <CardActions sx={{ justifyContent: 'center' }}>
                <Button
                  onClick={handleOpenAddModal}
                  startIcon={<AddIcon />}
                  variant="outlined"
                  color="primary"
                >
                  Add Service
                </Button>
              </CardActions>
            </Card>
          )}
          {servicedetails.length > 0 && (
            <Button
              onClick={handleOpenAddModal}
              startIcon={<AddIcon />}
              variant="outlined"
              color="primary"
              sx={{ position: 'absolute', top: '30px', right: '50px' }}
            >
              Add Service
            </Button>
          )}
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'row',
              flexWrap: 'wrap',
              justifyContent: 'flex-start',
              mt: 4,
              gap: '16px', // Adjust spacing between cards
              marginTop: '50px',
            }}
          >
            {servicedetails.map((service) => (
              <Card
                key={service._id}
                sx={{
                  width: '100%',
                  maxWidth: 'calc(33.33% - 16px)', // Adjust card width as needed
                  marginBottom: '16px', // Add margin bottom to separate cards
                }}
              >
                <CardContent>
                  <Typography variant="h5" gutterBottom color={"blue"}>
                    {service.title}
                  </Typography>
                  <Typography variant="body1">
                    {service.description}
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button
                    startIcon={<EditIcon />}
                    onClick={() => handleOpenEditModal(service)}
                  >
                    Edit
                  </Button>
                  <Button
                    startIcon={<DeleteIcon />}
                    onClick={() => handleDelete(service._id)}
                    color="error"
                  >
                    Delete
                  </Button>
                </CardActions>
              </Card>
            ))}
          </Box>
          {/* Add Service Modal */}
          <Modal
            open={openAddModal}
            onClose={handleCloseAddModal}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          >
            <Box
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: '80%',
                maxWidth: 600,
                bgcolor: 'background.paper',
                boxShadow: 24,
                p: 4,
              }}
            >
              <Typography id="modal-modal-title" variant="h6">
                Add Service
              </Typography>
              <form onSubmit={addServiceSubmit}>
                <TextField
                  size="small"
                  value={serviceInput.title}
                  name="title"
                  onChange={serviceHandleChange}
                  label="Title"
                  fullWidth
                  sx={{ mb: 2 }}
                />
                <TextField
                  size="small"
                  value={serviceInput.description}
                  name="description"
                  onChange={serviceHandleChange}
                  label="Description"
                  fullWidth
                  sx={{ mb: 2 }}
                />
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                  <Button
                     onClick={handleCloseAddModal}
             
                    variant="contained"
                    sx={{ mr: 2, width: '100px' }}
                    color="primary"
                  >
                  Cancel
                   
                  </Button>
                  <Button
                    variant="contained"
                        type="submit"
                    sx={{ width: '100px' }}
                  >
                    Add
                  </Button>
                </Box>
              </form>
            </Box>
          </Modal>
          {/* Edit Service Modal */}
          <Modal
            open={openEditModal}
            onClose={handleCloseEditModal}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          >
            <Box
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: '80%',
                maxWidth: 600,
                bgcolor: 'background.paper',
                boxShadow: 24,
                p: 4,
              }}
            >
              <Typography id="modal-modal-title" variant="h6">
                Edit Service
              </Typography>
              <form onSubmit={updateServiceSubmit}>
                <TextField
                  size="small"
                  value={serviceInput.title}
                  name="title"
                  onChange={serviceHandleChange}
                  label="Title"
                  fullWidth
                  sx={{ mb: 2 }}
                />
                <TextField
                  size="small"
                  value={serviceInput.description}
                  name="description"
                  onChange={serviceHandleChange}
                  label="Description"
                  fullWidth
                  sx={{ mb: 2 }}
                />
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                  <Button
                 onClick={handleCloseEditModal}
                    variant="contained"
                    sx={{ mr: 2, width: '100px' }}
                    color="primary"
                  >
                      Cancel
                  </Button>
                  <Button
                     type="submit"
                    variant="contained"
                    
                    sx={{ width: '100px' }}
                  >
                  Update 
                  </Button>
                </Box>
              </form>
            </Box>
          </Modal>
        </Box>
      </Box>
    </>
  );
};

export default Services;
