import React, { useContext } from 'react';
import SideBar from '../components/SideBar';
import { Box, Card, CardContent, Typography, Grid, Grow, CardActionArea, Checkbox, FormControlLabel } from '@mui/material';
import { AccountCircle } from '@mui/icons-material';
import { myContext } from '../context/Appcontext';
import Home from '../gourav/Home';

const Dashboard = () => {
  const themecontext = useContext(myContext);
  const { vcardtheme, setvcardtheme } = themecontext;

  const themes = [
    { id: "1", name: "Theme1", creator: "Gaurav" },
    { id: "2", name: "Theme2", creator: "Ashish" },
    { id: "3", name: "Theme3", creator: "Anirudh" },
  ];

  const handleThemeClick = (theme) => {
    setvcardtheme(theme);
  };

  return (
    <>
      <Box
        sx={{
          display: "flex",
          backgroundColor: "rgb(238,238,238)",
          // height: "100vh",
        }}
      >
        <SideBar />
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            p: 3,
            marginTop: "3rem",
          }}
        >
          <Grid container spacing={3}>
            {themes.map((theme) => (
              <Grid item xs={12} sm={6} md={4} key={theme.id}>
                <Grow in={true}>
                  <Card
                    style={{
                      cursor: 'pointer',
                      position: 'relative',
                    }}
                  >
                    <CardActionArea onClick={() => handleThemeClick(theme.id)}>
                      <CardContent>
                        <Typography variant="h5" component="h2">
                          {theme.name}
                        </Typography>
                        <Typography color="textSecondary">
                          Created by {theme.creator}
                        </Typography>
                      </CardContent>
                      {vcardtheme === theme.id && (
                        <Box style={{ position: 'absolute', top: '50%', right: '8px', transform: 'translateY(-50%)' }}>
                          <FormControlLabel
                            control={<Checkbox checked color="primary" />}
                            label=""
                            labelPlacement="end"
                          />
                        </Box>
                      )}
                    </CardActionArea>
                  </Card>
                </Grow>
              </Grid>
            ))}
          </Grid>
        </Box>
      </Box>

      {/* <Home/> */}
    </>
  );
};

export default Dashboard;
