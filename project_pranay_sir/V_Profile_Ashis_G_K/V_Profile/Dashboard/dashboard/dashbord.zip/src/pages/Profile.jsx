import { Avatar, Box, Button, Grid, TextField, Typography } from "@mui/material";
import React, { useContext, useEffect, useState } from "react";
import SideBar from "../components/SideBar";
import { myContext } from "../context/Appcontext";
import axios from "axios";

const Profile = () => {
  const [profileId, setProfileId] = useState("");
  const [userdetails, setUserdetails] = useState([]);
  const [profileInput, setprofileInput] = useState({
    name: "",
    email: "",
    phoneNumber: "",
    address: "",
  });
  const profileContext = useContext(myContext);
  const {
    createProfile,
    updateProfile,
    deleteProfile,
    token,
    url,
    userId,
    reload,
    user
  } = profileContext;
  const { name, email, phoneNumber, address } = profileInput;

  // onchange handler
  const profileHandleChange = (e) => {
    const { name, value } = e.target;
    setprofileInput({ ...profileInput, [name]: value });
  };

  // submit handler
  const profileSubmit = async (e) => {
    e.preventDefault();
    if (userdetails.length < 1) {
      await createProfile(name, email, phoneNumber, address);
    } else {
      await updateProfile(profileId, name, email, phoneNumber, address);
    }
  };

  return (
    <>
      <Box
        sx={{
          display: "flex",
          backgroundColor: "rgb(238,238,238)",
          height: "100vh",
        }}
      >
        {/* Sidebar */}
        <SideBar />

        {/* Main Content */}
        <Box component="main" sx={{ flexGrow: 1, p: 3, marginTop: "3rem" }}>
          <Box
            sx={{
              height: "87vh",
              backgroundColor: "rgb(255,255,255)",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {/* Profile Form Container */}
            <Box
              sx={{
                width: { xs: "100%", sm: "80%", md: "60%" },
                textAlign: "center",
                p: 4,
                border: "1px solid #ccc",
                borderRadius: 4,
                boxShadow: 1,
              }}
              component="form"
              onSubmit={profileSubmit}
            >
              {/* Avatar Section */}
              <Avatar
                alt={user.name || "P"}
                src={user.imgurl}  
                sx={{ width: 100, height: 100, mb: 2, alignSelf: "center" }}
              />

              {/* Profile Heading */}
              <Typography variant="h4" className="fw-bold mb-4">
                Profile
              </Typography>

              {/* Grid for Inputs */}
              <Grid container spacing={2} justifyContent="center">
                {/* Name and Email */}
                <Grid item xs={12} sm={6}>
                  <TextField
                    size="small"
                    value={user.name || "not available"}
                    name="name"
                    onChange={profileHandleChange}
                    label="Name"
                    fullWidth
                    sx={{ mb: 2 }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    size="small"
                    value={user.email || "not available"}
                    name="email"
                    onChange={profileHandleChange}
                    label="Email"
                    fullWidth
                    sx={{ mb: 2 }}
                  />
                </Grid>

                {/* Phone Number and Address */}
                <Grid item xs={12} sm={6}>
                  <TextField
                    size="small"
                    value={user.phone || "not available"}
                    name="phone"
                    onChange={profileHandleChange}
                    label="Phone Number"
                    fullWidth
                    sx={{ mb: 2 }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    size="small"
                    value={user.address || "not available"}
                    name="address"
                    onChange={profileHandleChange}
                    label="Address"
                    fullWidth
                    sx={{ mb: 2 }}
                  />
                </Grid>
              </Grid>

              {/* Update Button */}
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                fullWidth
                sx={{ mt: 2 }}
              >
                Update
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default Profile;
