import React from 'react'

const Related_Product = () => {
  return (
    <div>Related_Product</div>
  )
}

export default Related_Product