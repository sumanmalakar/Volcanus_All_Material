// const fetchDataFromAPI = () => {
//   return new Promise((resolve, reject) => {
//     fetch("https://jsonplaceholder.typicode.com/todos").then((res) => {
//       if (!res.ok) {
//         return reject("Internal server error");
//       } else {
//         return resolve(res.json());
//       }
//     });
//   });
// };

// fetchDataFromAPI()
//   .then((data) => console.log(data))
//   .catch((err) => console.log(err));

console.log(n)
var n = 10