import React from 'react'

const App = () => {
  return (
    <>
    <div>
      <h1>Hello</h1>
    </div>

    <div>
      <h1>Prashant</h1>
    </div>
    </>
    
  )
}

export default App