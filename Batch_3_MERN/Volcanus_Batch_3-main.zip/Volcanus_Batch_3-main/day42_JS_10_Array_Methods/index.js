const arr = [
  "Oneplus",
  "iphone",
  "Sony Xperia",
  "HTC Desire",
  "Blackberry",
  "Lumia",
];

// console.log(arr)
// console.log("First element has been removed ",arr.shift())
arr.unshift("LAVA","Aditya")
for(let value of arr){
console.log(value)
}



