// Strings
// const str = "SUPER MAN ";

// to convert string to upperCase
// const result = str.toUpperCase()

// to convert string to lowerCase
// const result = str.toLowerCase()

// to remove space from starting and ending from string
// console.log(str)
// const result = str.trim()
// console.log(result)


// const str = "superman"
// to find a length of a string
// console.log(str.length)

const str = "superman"; 
console.log(str.charAt(4))
