import React from "react";
import Person from "./Person";
import Superman from "./Superman";
import Image from "./Image";
import Conditional_Rendering from "./Conditional_Rendering";

const App = () => {
  return (
    <>
      {/* <Superman />
      <Person /> */}
      {/* <Image /> */}
      <Conditional_Rendering />
    </>
  );
};

export default App;
