import React from 'react'

const Superman = () => {
  return (
    <div>Superman</div>
  )
}

export default Superman