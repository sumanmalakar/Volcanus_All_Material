const person = {
  name: "superman",
  age: 200,
  salary: 100,
  from: "DC",
  detail: function () {
    // console.log("this data is coming from this keyword ",this);
    console.log("atul",this)
  },
};
console.log(person);
