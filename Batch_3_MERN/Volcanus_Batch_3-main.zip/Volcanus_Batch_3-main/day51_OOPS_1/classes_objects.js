// class Car {
//   constructor(brandName, price) {
//     this.brandName = brandName;
//     this.price = price;
//   }
//   displayInfo = () => {
//     console.log(`Car: ${this.brandName} ${this.price}`);
//   };
// }

// const myCar = new Car("Toyota", "Corolla");
// myCar.displayInfo(); 

class Car {
    constructor(brndName){
        console.log("This is car constructor",brndName)
    }
}
const varibale = new Car("BMW");
const aryan = new Car();