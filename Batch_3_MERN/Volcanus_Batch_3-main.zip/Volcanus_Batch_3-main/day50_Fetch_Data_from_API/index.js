// console.log("Hello Console")

console.log("Hello 1")

setTimeout(() => {
    console.log("This is inside setTimout")
}, 2000);

console.log("Hello 2")

setTimeout(() => {
  console.log("This is inside setTimout 2");
}, 1000);

console.log("Hello 3");
