
// High Order Array Method
const superman = [
  { id: 1, title: "iphone15" },
  { id: 2, title: "Sony Xperia" },
  { id: 3, title: "HTC Desire" },
  { id: 4, title: "BlackBerry" },
  { id: 5, title: "Nokia Lumia 430" },
];

superman.map((data)=>console.log(data))