import React from 'react'
import StateGov from './StateGov'
const IndianGov = ({data}) => {
  return (
    <div>
      <h1>This is IndianGov</h1>
      <StateGov data={data} />
    </div>
  );
}

export default IndianGov