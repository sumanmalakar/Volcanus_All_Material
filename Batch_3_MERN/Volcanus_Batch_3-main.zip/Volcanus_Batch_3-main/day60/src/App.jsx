import React from 'react'
import Use_Effect from './components/Use_Effect'
import FetchData from './components/FetchData'
import MealDb from './components/MealDb'

const App = () => {
  return (
    <>
    {/* <Use_Effect /> */}
    {/* <FetchData /> */}
    <MealDb />
    
    </>
  )
}

export default App