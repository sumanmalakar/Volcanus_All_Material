// Arrays
const arr = [10,20,30,50,"Apple","Orange","Mango",2345.45,987.12]

// console.log(arr)
// console.log(arr[4])
// arr.push("Superman")
arr.pop()
for(let i = 0; i<arr.length; i++){
    console.log(arr[i])
}



