// additon +
// substraction -
// multiply *
// divition /
// modulo %
// preIncrement ++a
// postIncrement a++
// and => && or => ||
// true , false

// let a = 10
// let b = 20
// console.log("addition ",a+b)
// console.log("substraction ",a-b)
// console.log("multiplication ",a*b)
// console.log("division ",a/b)
// console.log("modulo ",a%b)
// console.log("preIncrement Operator ",++a)
// console.log("preIncrement Operator ",++b)
// console.log("posIncrement Operator ",b++)
// console.log("posIncrement Operator ",a++)

// let dollar = 100000;
// let drivingLicense = false;

// if (dollar > 10000) {
//   if (drivingLicense) {
//     console.log("you can purchase BMW car");
//   } else {
//     console.log(
//       "You have money that is fine but you dont have DL , show you cant purchase BMW car"
//     );
//   }
// } else {
//   console.log("First you have to make money at least 10000");
// }
// aditi => 28
// prashat => 28
// s => 31
// aditya => 31
// sanchit => 31
// atul => 28

// let rupees = 10000;

// if (rupees >= 40000) {
//   console.log("You can buy Oneplus");
// } else if (rupees == 30000) {
//   console.log("You can buy poco");
// } else {
//   console.log("Nokia 3310");
// }

// let number = 10;

// if (number === "10") {
//   console.log("Amazon");
// } else {
//   console.log("Microsoft");
// }

// == value ✔ type X
// === value ✔ type ✔

let age = 20

if(age>=18){
    console.log("you can")
}