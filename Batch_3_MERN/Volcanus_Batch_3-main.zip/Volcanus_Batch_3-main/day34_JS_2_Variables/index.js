
// int a = 10;

// char ch = 'a'

// float salary = 2300000.4343

// char string[] = "superman"

// let student = "sanchit"

// console.log("Variable type = ", student)

// student = "prashant"

// console.log("Variable type = ", student)


// let a = 10

// let b = 20

// let sum = a+b;

// console.log("Sum of a and b is = ",sum)

// const empId = "ab"

// empId = 10

// console.log("This is my employee Id ",empId)


const name1 = "superman"
const name2 = "spiderman"

// "superman" is belong from "Dc" and "spiderman" man is belong from "Marvel"

 ' "Dc" ' 
 ' "Marvel" '

// concatenation
// console.log( '"'+name1+'"' +' is belong from "Dc" and '+name2+' is belong from "Marvel"') 

// console.log(`"${name1}" is belong from "DC" and "${name2}" is belong from "Marvel" `)

// additon +
// substraction - 
// multiply *
// divition /
// modulo %
// preIncrement ++a
// postIncrement a++
// and => && or => ||
// true , false
// 

let a = 20 

console.log(++a, a++);

// aditya => 21, 22 w
// atul => 21, 21 r
// aryan => 19 , 21 w
// prashant =>19, 22 ww
// siyush => 21,21 r
// sanchit => 20, 21 w