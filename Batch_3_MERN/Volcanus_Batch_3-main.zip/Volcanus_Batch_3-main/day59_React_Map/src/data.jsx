export const data = [
  {
    id: 1,
    category: "london",
    imgsrc:
      "https://images.pexels.com/photos/220887/pexels-photo-220887.jpeg?auto=compress&cs=tinysrgb&h=350",
  },
  {
    id: 2,
    category: "london",
    imgsrc:
      "https://images.pexels.com/photos/575362/pexels-photo-575362.jpeg?auto=compress&cs=tinysrgb&h=350",
  }, 
  {
    id: 3,
    category: "paris",
    imgsrc:
      "https://images.pexels.com/photos/20261802/pexels-photo-20261802.jpeg?auto=compress&cs=tinysrgb&h=350",
  },
  {
    id: 4,
    category: "paris",
    imgsrc:
      "https://images.pexels.com/photos/20149873/pexels-photo-20149873.jpeg?auto=compress&cs=tinysrgb&h=350",
  },
  {
    id: 5,
    category: "mumbai",
    imgsrc:
      "https://images.pexels.com/photos/4873310/pexels-photo-4873310.jpeg?auto=compress&cs=tinysrgb&h=350",
  },
  {
    id: 6,
    category: "mumbai",
    imgsrc:
      "https://images.pexels.com/photos/4684018/pexels-photo-4684018.jpeg?auto=compress&cs=tinysrgb&h=350",
  },
  {
    id: 7,
    category: "tokyo",
    imgsrc:
      "https://images.pexels.com/photos/1510595/pexels-photo-1510595.jpeg?auto=compress&cs=tinysrgb&h=350",
  },
  {
    id: 8,
    category: "tokyo",
    imgsrc:
      "https://images.pexels.com/photos/3048516/pexels-photo-3048516.jpeg?auto=compress&cs=tinysrgb&h=350",
  },
];
