import React from 'react'

const Person = () => {
  return (
    <div>Person</div>
  )
}

export default Person