// console.log("Hello Console");
// const day = 1;
// switch (day) {
//   case 1:
//     console.log("Today is Monday");
//     break;
//   case 2:
//     console.log("Tuesday");
//     break;
//   case 3:
//     console.log("Wed");
//     break;
//   case 4:
//     console.log("Thur");
//     break;
//   case 5:
//     console.log("Friday");
//     break;
//   case 6:
//     console.log("Saturday");
//     break;
//   case 7:
//     console.log("Sunday");
//     break;
// }

// let a = 10;
// let b = 20;
// let c = a + b;
// console.log(c);

function superman(a,b){
  console.log(a+b)
}

superman(10,20)
superman(400,500)
superman(600,700)

// () => parenthesis
// {} => circly bracket
// [] => square bracket
