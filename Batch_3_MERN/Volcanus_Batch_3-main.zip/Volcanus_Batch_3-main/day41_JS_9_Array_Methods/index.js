// const student = {
//     name:"prashant",
//     rollNo:1234,
//     gmail:"prashant@gmail.com",
//     course:"frontend"
// }

// const phone1 = "iphone"
// const phone2 = "oneplus"
// const phone3 = "samsung"

const phone = ["iphone", "oneplus","vivo","oppo","mi","samsung"];

// To adding a new element in array [internally it use - Stack]
// phone.push("Superman")

// To remove element from last
// phone.pop()
// phone.pop()

// for(let i=0; i<phone.length; i++){
//     console.log("before remove ",phone[i])
//     phone.pop();
//     console.log("after remove ",phone)
// }

// for (let  of phone) {
//   console.log("before remove ", );
//       phone.pop();
//   console.log("after remove ", phone);
// }
