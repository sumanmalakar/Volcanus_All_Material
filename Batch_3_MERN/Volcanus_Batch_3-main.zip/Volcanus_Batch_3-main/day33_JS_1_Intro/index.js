console.log("Hello World")

console.log(20+30)