// let number = 20

// if(number === "20"){
//     console.log("This is a number ")
// } else{
//     console.log("This is not a number")
// }


let age = 2;

// if(age>18){
//     console.log('You can driver')
// }else{
//     console.log('You can not drive')
// }

age > 18 ? console.log("You can driver") : console.log("You can not drive");

