function TodoItem2()
{
   return<div class="container text-center">


   <div class="row">
       <div class="col-6">
       Buy Milk
       </div>
       <div class="col-4">
       4/10/2024
       
       </div>
       <div class="col-2">
         <button type="button" class="btn btn-danger">Delete</button>
   
       </div>
     </div>
     </div>


}
export default TodoItem2
